<?php
header('Access-Control-Allow-Origin: *');
error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: application/json');

// Connect to the database
$db = mysqli_connect('localhost', 'root', '', 'bookbytes_userdb');
if (!$db) {
    echo json_encode("Database connection failed");
    exit;
}

// Retrieve and sanitize input
$name = mysqli_real_escape_string($db, $_POST['name'] ?? '');
$password = mysqli_real_escape_string($db, $_POST['password'] ?? '');
$email = mysqli_real_escape_string($db, $_POST['email'] ?? '');

// Check if username and password are provided
if (empty($name) || empty($password) || empty($email)) {
    echo json_encode("Error: Username, Password, and Email are required");
    exit;
}

// Check if the user already exists
$stmt = $db->prepare("SELECT email FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$count = $result->num_rows;

if ($count == 1) {
    echo json_encode("Error: User already exists");
} else {
    // Hash the password for security
    // $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Prepare and bind parameters for insert
    $insert = $db->prepare("INSERT INTO users (name, password, email) VALUES (?, ?, ?)");
    $insert->bind_param("sss", $name, $password, $email);

    // Execute the insert and check for success
    if ($insert->execute()) {
        echo json_encode("Success");
    } else {
        echo json_encode("Error");
    }
    
}
?>

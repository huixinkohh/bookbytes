<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

$db = mysqli_connect('localhost', 'root', '', 'bookbytes_userdb');
if (!$db) {
    die(json_encode("Error: Unable to connect to database."));
}

$userInput = $_POST['userInput'] ?? ''; 
$password = $_POST['password'] ?? '';

if (!$userInput || !$password) {
    echo json_encode("Error: Email or Password is not provided");
    exit;
}

// Query to check against both username and email
$stmt = $db->prepare("SELECT * FROM users WHERE email = ? AND password = ?");
$stmt->bind_param("ss", $userInput, $password);
$stmt->execute();
$result = $stmt->get_result();
$count = $result->num_rows;

if ($count == 1) {
    echo json_encode("Success");
} else {
    echo json_encode("Error");
}
?>
